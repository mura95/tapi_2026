using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public partial class SleepController : MonoBehaviour
{

    /// <summary>
    /// 睡眠のスケジュールを設定
    /// </summary>
    private void ScheduleSleep(int sleepHour = 22, TimeZoneInfo tz = null, DateTime? now = null)
    {
        tz ??= TimeZoneInfo.Local;
        now ??= TimeZoneInfo.ConvertTime(DateTime.UtcNow, tz);
        CancelInvoke(nameof(StartSleepingBridge));
        DateTime sleepTime = new DateTime(now.Value.Year, now.Value.Month, now.Value.Day, sleepHour, 0, 0);
        //後ほど消す
        if (_dogController.GetSleeping())
        {
            WakeUp();
        }
        if (now > sleepTime)
        {
            sleepTime = sleepTime.AddDays(1);
        }
        // TimeSpanの差分を計算
        TimeSpan timeDifference = sleepTime - now.Value;
        double secondsUntilSleep = timeDifference.TotalSeconds;
        Invoke(nameof(StartSleepingBridge), (float)secondsUntilSleep);

        // 次回睡眠予定時間を保存（デバッグ用）
        nextScheduledSleepTime = sleepTime;
        Debug.Log($"次のスリープスケジュール: {sleepTime} (残り {secondsUntilSleep} 秒)");
    }

    public void ResetAllSchedules(TimeZoneInfo tz = null)
    {
        tz ??= selectedTimeZone ?? TimeZoneInfo.Local;

        // すべてのスケジュールをキャンセル
        CancelInvoke(nameof(StartSleepingBridge));
        CancelInvoke(nameof(WakeUp));
        CancelInvoke(nameof(OnNapEndTimeReached));

        if (_sleepyReactionCoroutine != null)
        {
            StopCoroutine(_sleepyReactionCoroutine);
            _sleepyReactionCoroutine = null;
            _isInSleepyReaction = false;
        }

        // 現在の状態に基づいて次のスケジュールを設定
        ManageSleepCycle(tz);
    }

    public void ManageSleepCycle(TimeZoneInfo tz)
    {
        if (tz == null)
        {
            Debug.LogError("[ManageSleepCycle] tz が null です！");
            tz = TimeZoneInfo.Local;
        }

        DateTime now = TimeZoneInfo.ConvertTime(DateTime.UtcNow, tz);
        int sleepHour = PlayerPrefs.GetInt(SLEEP_HOUR_KEY, 22);
        int wakeHour = PlayerPrefs.GetInt(WAKE_HOUR_KEY, 6);

        bool isSleepTime = (now.Hour >= sleepHour || now.Hour < wakeHour);
        bool isSleeping = _dogController != null && _dogController.GetSleeping();

        Debug.Log($"[ManageSleepCycle] 現在時刻: {now.Hour}時 / 寝る時間帯か？ {isSleepTime} / ペットは寝ているか？ {isSleeping}");

        if (isSleepTime && !isSleeping)
        {
            Debug.Log("[ManageSleepCycle] 現在は就寝時間で、ペットが起きているので StartSleeping() を呼びます");
            StartSleeping(tz);
        }
        else if (!isSleepTime && isSleeping)
        {
            Debug.Log("[ManageSleepCycle] 現在は起床時間で、ペットが寝ているので WakeUp() を呼びます");
            WakeUp();
        }
        else if (!isSleepTime)
        {
            // 起きている時間 → 次の sleep のみ予約
            Debug.Log("[ManageSleepCycle] 起きている時間帯なので、次回の睡眠スケジュールを組みます");
            ScheduleSleep(sleepHour, tz, now);
        }
        // 寝ている時間中（isSleepTime && isSleeping）は何もしない
        // → AndroidアラームがWakeUpを担当
    }
}
