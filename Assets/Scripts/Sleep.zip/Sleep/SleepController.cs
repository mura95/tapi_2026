using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// SleepController - デバッグログ強化版 + 自動3サイクルテスト対応
/// アラームの動作状況を詳細に記録し、自動テストも実行可能
/// </summary>
public partial class SleepController : MonoBehaviour
{
    private IAlarmScheduler _alarm;
    private IPowerService _power;
    private DailyWakeScheduler _dailyWake;

    [Header("自動テストモード")]
    [SerializeField] private bool _autoTestMode = false;
    [SerializeField] private int _testCycleCount = 3;
    [SerializeField] private float _sleepDelayMinutes = 2f;
    [SerializeField] private float _wakeDelayMinutes = 3f;

    private int _currentTestCycle = 0;
    private bool _isTestRunning = false;
    public bool IsAutoTestMode => _autoTestMode;

    // 参照
    [SerializeField] private DogController _dogController;
    [SerializeField] private FirebaseManager _firebaseManager;
    [SerializeField] private HungerManager _hungryManager;
    [SerializeField] private FirebaseUIManager _firebaseUIManager;
    [SerializeField] private MainUIButtons _mainUiButtons;
    [SerializeField] private DebugCanvasManager _debugCanvasManager;

    // 時刻系
    private const string SLEEP_HOUR_KEY = "SleepHour";
    private const string WAKE_HOUR_KEY = "WakeHour";
    private TimeZoneInfo selectedTimeZone;
    private List<TimeZoneInfo> timeZones;

    private DateTime? nextScheduledSleepTime = null;
    public DateTime? NextScheduledSleepTime => nextScheduledSleepTime;

    private DateTime? nextScheduledWakeTime = null;
    public DateTime? NextScheduledWakeTime => nextScheduledWakeTime;

    void Awake()
    {
        Debug.Log("========================================");
        Debug.Log("[SleepController] Awake() called");
        Debug.Log("========================================");

#if UNITY_ANDROID && !UNITY_EDITOR
        Debug.Log("[SleepController] Platform: Android (Real Device)");
        _alarm = new AndroidAlarmScheduler();
        _power = new AndroidPowerService();
#else
        Debug.Log("[SleepController] Platform: Editor");
        _alarm = new EditorAlarmScheduler(this);
        _power = new NoopPowerService();
#endif

        Debug.Log($"[SleepController] Alarm scheduler: {_alarm.GetType().Name}");
        Debug.Log($"[SleepController] Power service: {_power.GetType().Name}");
        Debug.Log($"[SleepController] Auto Test Mode: {_autoTestMode}");
    }

    void Start()
    {
        Debug.Log("========================================");
        Debug.Log("[SleepController] Start() called");
        Debug.Log("========================================");

        StartOverdueMonitoring();
        Screen.sleepTimeout = SleepTimeout.NeverSleep;
        Debug.Log("[SleepController] Screen sleep timeout set to NeverSleep");

        selectedTimeZone = TimeZoneUtility.InitializeTimeZone((idx, tzList) =>
        {
            timeZones = tzList;
            _firebaseUIManager.setDropdownValue(idx, tzList);
        });
        Debug.Log($"[SleepController] Selected TimeZone: {selectedTimeZone.DisplayName}");
        Debug.Log($"[SleepController] TimeZone ID: {selectedTimeZone.Id}");
        Debug.Log($"[SleepController] Current offset: {selectedTimeZone.GetUtcOffset(DateTime.UtcNow)}");

        int sleepHour = PlayerPrefs.GetInt(SLEEP_HOUR_KEY, 22);
        int wakeHour = PlayerPrefs.GetInt(WAKE_HOUR_KEY, 6);
        Debug.Log($"[SleepController] Sleep hour: {sleepHour}");
        Debug.Log($"[SleepController] Wake hour: {wakeHour}");

        if (_autoTestMode)
        {
            Debug.Log("========================================");
            Debug.Log("[SleepController] ⚠️ AUTO TEST MODE ACTIVE");
            Debug.Log($"[SleepController] Test cycles: {_testCycleCount}");
            Debug.Log($"[SleepController] Sleep delay: {_sleepDelayMinutes} minutes");
            Debug.Log($"[SleepController] Wake delay: {_wakeDelayMinutes} minutes");
            Debug.Log("========================================");

            _debugCanvasManager.ShowDebugCanvas();
            StartCoroutine(AutoTestCycle());
        }
        else
        {
            Debug.Log("[SleepController] Normal mode");
            _dailyWake = new DailyWakeScheduler(_alarm, selectedTimeZone);
            _dailyWake.EnsureDailyWakeAtHour();
            ManageSleepCycle(selectedTimeZone);
        }

        // 昼寝機能の初期化
        InitializeNap();
        ResetAllSchedules();
        Debug.Log("[SleepController] Nap functionality initialized");

        Debug.Log("========================================");
        Debug.Log("[SleepController] Start() completed");
        Debug.Log("========================================");
    }

    /// <summary>
    /// 自動テストサイクルを実行（3回のスリープ→起床を自動実行）
    /// </summary>
    private IEnumerator AutoTestCycle()
    {
        _isTestRunning = true;
        DateTime startTime = TimeZoneInfo.ConvertTime(DateTime.UtcNow, selectedTimeZone);

        Debug.Log("========================================");
        Debug.Log($"[AutoTest] Starting automatic test cycle");
        Debug.Log($"[AutoTest] Start time: {startTime:yyyy-MM-dd HH:mm:ss}");
        Debug.Log("========================================");

        for (int cycle = 1; cycle <= _testCycleCount; cycle++)
        {
            _currentTestCycle = cycle;

            Debug.Log("========================================");
            Debug.Log($"[AutoTest] CYCLE {cycle}/{_testCycleCount} START");
            Debug.Log("========================================");

            // 現在時刻を取得
            DateTime now = TimeZoneInfo.ConvertTime(DateTime.UtcNow, selectedTimeZone);

            // スリープ時刻と起床時刻を計算
            DateTime sleepTime = now.AddMinutes(_sleepDelayMinutes);
            DateTime wakeTime = now.AddMinutes(_sleepDelayMinutes + _wakeDelayMinutes);

            Debug.Log($"[AutoTest] Current time: {now:HH:mm:ss}");
            Debug.Log($"[AutoTest] Sleep scheduled: {sleepTime:HH:mm:ss} (+{_sleepDelayMinutes:F0} min)");
            Debug.Log($"[AutoTest] Wake scheduled: {wakeTime:HH:mm:ss} (+{(_sleepDelayMinutes + _wakeDelayMinutes):F0} min)");

            // スリープをスケジュール
            float sleepDelaySeconds = (float)(sleepTime - now).TotalSeconds;

            Debug.Log($"[AutoTest] Starting sleep in {sleepDelaySeconds:F1} seconds");

            CancelInvoke(nameof(StartSleepingBridge));
            Invoke(nameof(StartSleepingBridge), sleepDelaySeconds);

            // スリープが実行されるまで待つ
            yield return new WaitForSeconds(sleepDelaySeconds + 5f); // 5秒のバッファ

            // スリープが実行されたか確認
            if (GlobalVariables.CurrentState == PetState.sleeping)
            {
                Debug.Log($"[AutoTest] ✅ Cycle {cycle}: Sleep successful");
            }
            else
            {
                Debug.LogWarning($"[AutoTest] ⚠️ Cycle {cycle}: Sleep may have failed");
            }

            // 起床時刻まで待つ
            float wakeWaitSeconds = (float)(wakeTime - TimeZoneInfo.ConvertTime(DateTime.UtcNow, selectedTimeZone)).TotalSeconds;

            if (wakeWaitSeconds > 0)
            {
                Debug.Log($"[AutoTest] Waiting {wakeWaitSeconds:F1} seconds for wake alarm...");
                yield return new WaitForSeconds(wakeWaitSeconds + 10f); // 10秒のバッファ
            }

            // 起床が実行されたか確認
            if (GlobalVariables.CurrentState == PetState.idle)
            {
                Debug.Log($"[AutoTest] ✅ Cycle {cycle}: Wake successful");
            }
            else
            {
                Debug.LogWarning($"[AutoTest] ⚠️ Cycle {cycle}: Wake may have failed, current state: {GlobalVariables.CurrentState}");

                // 手動で起床を試みる
                Debug.Log($"[AutoTest] Attempting manual wake...");
                WakeUp();
            }

            Debug.Log("========================================");
            Debug.Log($"[AutoTest] CYCLE {cycle}/{_testCycleCount} COMPLETE");
            Debug.Log("========================================");

            // 次のサイクルまで少し待つ（状態安定のため）
            if (cycle < _testCycleCount)
            {
                Debug.Log($"[AutoTest] Preparing for next cycle...");
                yield return new WaitForSeconds(5f);
            }
        }

        DateTime endTime = TimeZoneInfo.ConvertTime(DateTime.UtcNow, selectedTimeZone);
        TimeSpan totalDuration = endTime - startTime;

        Debug.Log("========================================");
        Debug.Log($"[AutoTest] ALL CYCLES COMPLETED");
        Debug.Log($"[AutoTest] Start time: {startTime:HH:mm:ss}");
        Debug.Log($"[AutoTest] End time: {endTime:HH:mm:ss}");
        Debug.Log($"[AutoTest] Total duration: {totalDuration.TotalMinutes:F1} minutes");
        Debug.Log($"[AutoTest] Cycles completed: {_testCycleCount}");
        Debug.Log("========================================");

        _isTestRunning = false;

        // テスト完了後、通常モードに戻す
        Debug.Log("[AutoTest] Switching to normal mode...");
        _dailyWake = new DailyWakeScheduler(_alarm, selectedTimeZone);
        _dailyWake.EnsureDailyWakeAtHour();

        int sleepHour = PlayerPrefs.GetInt(SLEEP_HOUR_KEY, 22);
        ManageSleepCycle(selectedTimeZone);

        Debug.Log("[AutoTest] Test completed. App is now in normal mode.");
    }

    // Invokeで引数を渡せないのでブリッジ
    private void StartSleepingBridge() => StartSleeping(selectedTimeZone);

    public void StartSleeping(TimeZoneInfo tz = null)
    {
        Debug.Log("========================================");
        Debug.Log("[SleepController] StartSleeping() called");
        if (_autoTestMode && _isTestRunning)
        {
            Debug.Log($"[SleepController] Auto Test Mode - Cycle {_currentTestCycle}/{_testCycleCount}");
        }
        Debug.Log("========================================");

        if (_dogController.GetSleeping())
        {
            Debug.Log("[SleepController] Dog is already sleeping. Exiting StartSleeping().");
            return;
        }

        _dogController.UpdateTransitionState(1);
        GlobalVariables.CurrentState = PetState.sleeping;
        _dogController.Sleeping(true);
        _firebaseManager.UpdatePetState("sleeping");
        _mainUiButtons.UpdateButtonVisibility(false);
        Debug.Log("[SleepController] UI updated for sleep mode");

        tz ??= selectedTimeZone ?? TimeZoneInfo.Local;
        DateTime now = TimeZoneInfo.ConvertTime(DateTime.UtcNow, tz);
        Debug.Log($"[SleepController] Current time: {now:yyyy-MM-dd HH:mm:ss} ({tz.Id})");

        // 画面を暗くする
        BrightnessUtil.SetBrightness.DoAction(-1f);
        Debug.Log("[SleepController] Brightness reduced");

        // 起床時刻を計算
        DateTime nextWake;

        if (_autoTestMode && _isTestRunning)
        {
            // 自動テストモード: 現在時刻 + _wakeDelayMinutes
            nextWake = now.AddMinutes(_wakeDelayMinutes);
            Debug.Log($"[SleepController] Auto Test: Wake scheduled at {nextWake:HH:mm:ss} (+{_wakeDelayMinutes:F0} min)");
        }
        else
        {
            // 通常モード
            int wakeHour = PlayerPrefs.GetInt(WAKE_HOUR_KEY, 6);
            nextWake = new DateTime(now.Year, now.Month, now.Day, wakeHour, 0, 0);

            if (now >= nextWake)
            {
                nextWake = nextWake.AddDays(1);
                Debug.Log("[SleepController] Wake time is past today, moved to tomorrow");
            }
        }

        Debug.Log($"[SleepController] Scheduling wake at: {nextWake:yyyy-MM-dd HH:mm:ss}");
        _alarm.ScheduleWakeAt(nextWake, tz);
        nextScheduledWakeTime = nextWake;
        nextScheduledSleepTime = null;

        Screen.sleepTimeout = SleepTimeout.SystemSetting;
        _power.ClearKeepScreenOn();
        Debug.Log("[SleepController] StartSleeping() completed");
    }

    public void WakeUp()
    {
        Debug.Log("========================================");
        Debug.Log("[SleepController] WakeUp() called");
        if (_autoTestMode && _isTestRunning)
        {
            Debug.Log($"[SleepController] Auto Test Mode - Cycle {_currentTestCycle}/{_testCycleCount}");
        }
        Debug.Log("========================================");

        _power.TurnScreenOn();
        Debug.Log("[SleepController] Screen turned on");

        if (_dogController.GetSleeping())
        {
            GlobalVariables.CurrentState = PetState.idle;
            _dogController.Sleeping(false);
            _firebaseManager.UpdatePetState("idle");
            _mainUiButtons.UpdateButtonVisibility(true);
            Debug.Log("[SleepController] UI updated for wake mode");
        }
        else
        {
            Debug.Log($"[SleepController] State was not sleeping (current: {GlobalVariables.CurrentState})");
        }

        Screen.sleepTimeout = SleepTimeout.NeverSleep;
        Debug.Log("[SleepController] Screen sleep disabled (NeverSleep)");

        BrightnessUtil.SetBrightness.DoAction(1.0f);
        Debug.Log("[SleepController] Brightness restored");

        // 自動テストモードでない場合のみ次回スケジュールを設定
        if (!_autoTestMode || !_isTestRunning)
        {
            // 次回のスリープスケジュールを設定
            int sleepHour = PlayerPrefs.GetInt(SLEEP_HOUR_KEY, 22);
            Debug.Log($"[SleepController] Scheduling next sleep at {sleepHour}:00");
            ScheduleSleep(sleepHour, selectedTimeZone);
            nextScheduledWakeTime = null;
        }
        else
        {
            Debug.Log("[SleepController] Auto Test Mode: Skipping next sleep schedule (handled by AutoTestCycle)");
        }

        Debug.Log("========================================");
        Debug.Log("[SleepController] WakeUp() completed");
        Debug.Log("========================================");
    }

    public void TryAutoWake(string source)
    {
        Debug.Log($"[TryAutoWake] Source: {source}");

        if (_dogController == null)
        {
            Debug.LogWarning("[TryAutoWake] DogController is null");
            return;
        }

        if (selectedTimeZone == null)
        {
            selectedTimeZone = TimeZoneInfo.Local;
        }

        var now = TimeZoneInfo.ConvertTime(DateTime.Now, selectedTimeZone);

        // 条件：現在が起床時間を過ぎている AND ペットがまだ寝ているなら起こす
        if (now >= nextScheduledWakeTime && _dogController.GetSleeping())
        {
            Debug.Log("[TryAutoWake] 条件を満たしたため WakeUp() を実行します");
            WakeUp();
        }
        else
        {
            Debug.Log("[TryAutoWake] WakeUp条件を満たしていません");
        }
    }


    /// <summary>
    /// 睡眠スケジュールのみをキャンセル
    /// </summary>
    public void CancelSleepSchedule()
    {
        Debug.Log("[SleepController] CancelSleepSchedule() called");
        CancelInvoke(nameof(StartSleepingBridge));
        CancelInvoke(nameof(WakeUp));
        CancelNapSchedule();
        nextScheduledSleepTime = null;
        nextScheduledWakeTime = null;
        Debug.Log("[SleepController] All sleep schedules cancelled");
    }

    void OnApplicationPause(bool pause)
    {
        Debug.Log($"[SleepController] ========================================");
        Debug.Log($"[SleepController] OnApplicationPause: {pause}");
        Debug.Log($"[SleepController] Time: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        Debug.Log($"[SleepController] ========================================");

        if (!pause)
        {
            Debug.Log("[SleepController] App resumed from pause");
            TryAutoWake("resume");
        }
        else
        {
            Debug.Log("[SleepController] App paused");
        }
    }

    void OnApplicationFocus(bool hasFocus)
    {
        Debug.Log($"[SleepController] ========================================");
        Debug.Log($"[SleepController] OnApplicationFocus: {hasFocus}");
        Debug.Log($"[SleepController] Time: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        Debug.Log($"[SleepController] ========================================");

        if (hasFocus)
        {
            Debug.Log("[SleepController] App gained focus");
            TryAutoWake("focus");
        }
        else
        {
            Debug.Log("[SleepController] App lost focus");
        }
    }

    private void OnDestroy()
    {
        Debug.Log("[SleepController] OnDestroy() called");
        CancelInvoke(nameof(StartSleepingBridge));
        CancelInvoke(nameof(WakeUp));
        CancelNapSchedule();
        Screen.sleepTimeout = SleepTimeout.SystemSetting;

        if (_power != null)
        {
            _power.Release();
        }

        if (_autoTestMode && _isTestRunning)
        {
            StopAllCoroutines();
            Debug.Log("[SleepController] Auto test stopped");
        }

        nextScheduledSleepTime = null;
        nextScheduledWakeTime = null;
        StopOverdueMonitoring();
        Debug.Log("[SleepController] Cleanup completed");
    }

    public void UpdateTimeZone(TimeZoneInfo newTz)
    {
        selectedTimeZone = newTz;
        ResetAllSchedules(newTz);
    }

#if UNITY_ANDROID && !UNITY_EDITOR
    private void RequestIgnoreBatteryOptimizations()
    {
        Debug.Log("[SleepController] RequestIgnoreBatteryOptimizations() called");
        
        try
        {
            var unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
            var activity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");
            var pm = activity.Call<AndroidJavaObject>("getSystemService", "power");
            var pkg = activity.Call<string>("getPackageName");

            bool isIgnoring = pm.Call<bool>("isIgnoringBatteryOptimizations", pkg);
            Debug.Log($"[Battery] isIgnoringBatteryOptimizations: {isIgnoring}");

            if (!isIgnoring)
            {
                var intent = new AndroidJavaObject("android/content/Intent");
                intent.Call<AndroidJavaObject>("setAction", "android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS");
                var uri = new AndroidJavaClass("android/net/Uri")
                    .CallStatic<AndroidJavaObject>("parse", "package:" + pkg);
                intent.Call<AndroidJavaObject>("setData", uri);
                activity.Call("startActivity", intent);
                Debug.Log("[Battery] Requested battery optimization exemption");
            }
            else
            {
                Debug.Log("[Battery] Already ignoring battery optimizations");
            }
        }
        catch (System.Exception e)
        {
            Debug.LogWarning($"[Battery] RequestIgnoreBatteryOptimizations failed: {e.Message}");
        }
    }
#endif
}