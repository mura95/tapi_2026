using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimeZoneService : MonoBehaviour
{
    [SerializeField] private FirebaseUIManager _firebaseUIManager;
    [SerializeField] private SleepController _sleepController;
    private TimeZoneInfo selectedTimeZone;
    private List<TimeZoneInfo> timeZones;
    public void UpdateTimeZone(int newTimeZoneIndex)
    {
        if (timeZones == null || timeZones.Count == 0)
        {
            selectedTimeZone = TimeZoneUtility.InitializeTimeZone((idx, tzList) =>
            {
                timeZones = tzList;
                _firebaseUIManager.setDropdownValue(idx, tzList);
            });
            _sleepController.UpdateTimeZone(selectedTimeZone);  // 変更
        }

        if (newTimeZoneIndex >= 0 && newTimeZoneIndex < timeZones.Count)
        {
            selectedTimeZone = timeZones[newTimeZoneIndex];
            Debug.Log($"タイムゾーンが更新されました: {selectedTimeZone.DisplayName}");

            // 変更: 直接SleepControllerに新しいTimeZoneを設定
            _sleepController.UpdateTimeZone(selectedTimeZone);
        }
        else
        {
            Debug.LogError("更新インデックスが無効。再初期化します。");
            selectedTimeZone = TimeZoneUtility.InitializeTimeZone((idx, tzList) =>
            {
                timeZones = tzList;
                _firebaseUIManager.setDropdownValue(idx, tzList);
            });
            _sleepController.UpdateTimeZone(selectedTimeZone);  // 変更
        }
    }

}
