using UnityEngine;
using System.Collections.Generic;
using System;

namespace VoiceCommandSystem.Core
{
    /// <summary>
    /// マイクからの音声録音を管理
    /// 16kHz モノラル形式で録音し、音声データを提供
    /// Wake Word検出対応版
    /// </summary>
    public class AudioRecorder : MonoBehaviour
    {
        [Header("録音設定")]
        [SerializeField] private int sampleRate = 16000; // Whisperは16kHz推奨
        [SerializeField] private int maxRecordSeconds = 30; // 最大録音時間

        [Header("音声処理")]
        [SerializeField] private bool applyNoiseGate = false; // ノイズゲート適用（初期は無効）
        [SerializeField] private float noiseThreshold = 0.005f; // ノイズ閾値（より低く設定）

        private AudioClip micClip;
        private List<float> recordingBuffer = new List<float>();
        private bool isRecording = false;
        private int lastMicPosition = 0;
        private string microphoneDevice = null;

        // ★追加: Wake Word検出用のイベント
        public event System.Action<float[]> OnAudioDataReady;

        /// <summary>
        /// 録音を開始
        /// </summary>
        public bool StartRecording()
        {
            if (isRecording)
            {
                Debug.LogWarning("[AudioRecorder] Already recording");
                return false;
            }

            // 既存の録音を停止
            if (Microphone.IsRecording(microphoneDevice))
            {
                Microphone.End(microphoneDevice);
            }

            // マイク権限チェック
#if UNITY_ANDROID || UNITY_IOS
            if (!Application.HasUserAuthorization(UserAuthorization.Microphone))
            {
                Debug.LogError("[AudioRecorder] Microphone permission not granted");
                return false;
            }
#endif

            try
            {
                // マイク録音開始
                micClip = Microphone.Start(microphoneDevice, false, maxRecordSeconds, sampleRate);

                if (micClip == null)
                {
                    Debug.LogError("[AudioRecorder] Failed to start microphone");
                    return false;
                }

                recordingBuffer.Clear();
                lastMicPosition = 0;
                isRecording = true;

                Debug.Log($"[AudioRecorder] Recording started (device: {microphoneDevice ?? "default"}, rate: {sampleRate}Hz)");
                return true;
            }
            catch (Exception e)
            {
                Debug.LogError($"[AudioRecorder] Failed to start recording: {e.Message}");
                return false;
            }
        }

        /// <summary>
        /// 録音を停止し、音声データを取得
        /// </summary>
        public float[] StopRecording()
        {
            if (!isRecording)
            {
                Debug.LogWarning("[AudioRecorder] Not recording");
                return null;
            }

            try
            {
                // 最後のデータを取得
                CaptureAudioData();

                // 録音停止
                Microphone.End(microphoneDevice);
                isRecording = false;

                // バッファからデータを取得
                float[] audioData = recordingBuffer.ToArray();

                Debug.Log($"[AudioRecorder] Recording stopped. Captured {audioData.Length} samples ({audioData.Length / (float)sampleRate:F2}s)");

                // ノイズゲート適用（オプション）
                if (applyNoiseGate)
                {
                    audioData = ApplyNoiseGate(audioData);
                }

                // DC オフセット除去
                audioData = RemoveDCOffset(audioData);

                // 正規化
                audioData = NormalizeAudio(audioData);

                return audioData;
            }
            catch (Exception e)
            {
                Debug.LogError($"[AudioRecorder] Failed to stop recording: {e.Message}");
                isRecording = false;
                return null;
            }
        }

        void Update()
        {
            if (isRecording)
            {
                CaptureAudioData();
            }
        }

        /// <summary>
        /// マイクからの音声データをキャプチャ
        /// </summary>
        private void CaptureAudioData()
        {
            if (micClip == null) return;

            int currentPosition = Microphone.GetPosition(microphoneDevice);

            if (currentPosition < 0 || currentPosition == lastMicPosition)
            {
                return;
            }

            // データ取得
            int sampleCount = currentPosition - lastMicPosition;
            if (sampleCount < 0)
            {
                sampleCount += micClip.samples;
            }

            float[] samples = new float[sampleCount];
            micClip.GetData(samples, lastMicPosition);
            recordingBuffer.AddRange(samples);

            lastMicPosition = currentPosition;

            // ★追加: Wake Word検出器に音声データを配信
            OnAudioDataReady?.Invoke(samples);
        }

        /// <summary>
        /// ノイズゲート適用（低音量部分を削除）
        /// </summary>
        private float[] ApplyNoiseGate(float[] audioData)
        {
            List<float> filtered = new List<float>();
            int frameSize = sampleRate / 100; // 10ms フレーム
            int totalFrames = 0;
            int passedFrames = 0;

            for (int i = 0; i < audioData.Length; i += frameSize)
            {
                // フレームのエネルギー計算
                float energy = 0f;
                int count = Mathf.Min(frameSize, audioData.Length - i);

                for (int j = 0; j < count; j++)
                {
                    float sample = audioData[i + j];
                    energy += sample * sample;
                }
                energy /= count;

                totalFrames++;

                // 閾値を超えるフレームのみ残す
                if (energy > noiseThreshold)
                {
                    passedFrames++;
                    for (int j = 0; j < count; j++)
                    {
                        filtered.Add(audioData[i + j]);
                    }
                }
            }

            Debug.Log($"[AudioRecorder] Noise gate: {audioData.Length} → {filtered.Count} samples");
            Debug.Log($"[AudioRecorder] Frames: {passedFrames}/{totalFrames} passed (threshold: {noiseThreshold})");

            if (filtered.Count == 0)
            {
                Debug.LogWarning($"[AudioRecorder] ⚠️ All audio filtered out! Try:");
                Debug.LogWarning($"[AudioRecorder]   1. Lower noiseThreshold (current: {noiseThreshold})");
                Debug.LogWarning($"[AudioRecorder]   2. Disable applyNoiseGate");
                Debug.LogWarning($"[AudioRecorder]   3. Speak louder or closer to mic");
            }

            return filtered.ToArray();
        }

        /// <summary>
        /// DC オフセット除去
        /// </summary>
        private float[] RemoveDCOffset(float[] audioData)
        {
            float mean = 0f;
            foreach (float sample in audioData)
            {
                mean += sample;
            }
            mean /= audioData.Length;

            for (int i = 0; i < audioData.Length; i++)
            {
                audioData[i] -= mean;
            }

            return audioData;
        }

        private float[] NormalizeAudio(float[] audioData)
        {
            float peak = 0f;
            foreach (float sample in audioData)
            {
                float abs = Mathf.Abs(sample);
                if (abs > peak) peak = abs;
            }

            if (peak > 0f && peak < 0.9f)
            {
                float gain = 0.9f / peak;
                for (int i = 0; i < audioData.Length; i++)
                {
                    audioData[i] *= gain;
                }

                // 音量が非常に小さい場合の警告
                if (gain > 20f)
                {
                    Debug.LogWarning($"[AudioRecorder] ⚠️ Audio is very quiet (gain: {gain:F1})");
                    Debug.LogWarning("[AudioRecorder] Try: Speak louder or get closer to microphone");
                }
                else
                {
                    Debug.Log($"[AudioRecorder] Normalized audio (gain: {gain:F2})");
                }
            }

            return audioData;
        }

        /// <summary>
        /// 利用可能なマイクデバイスのリスト
        /// </summary>
        public static string[] GetAvailableDevices()
        {
            return Microphone.devices;
        }

        /// <summary>
        /// 使用するマイクデバイスを設定
        /// </summary>
        public void SetMicrophoneDevice(string deviceName)
        {
            microphoneDevice = deviceName;
            Debug.Log($"[AudioRecorder] Microphone device set to: {deviceName}");
        }

        /// <summary>
        /// 現在録音中か
        /// </summary>
        public bool IsRecording => isRecording;

        /// <summary>
        /// サンプルレート
        /// </summary>
        public int SampleRate => sampleRate;

        void OnDestroy()
        {
            if (isRecording)
            {
                Microphone.End(microphoneDevice);
            }
        }

        #region デバッグ用

        /// <summary>
        /// 音声データをWAVファイルとして保存（デバッグ用）
        /// </summary>
        public void SaveAsWav(float[] audioData, string filename)
        {
#if UNITY_EDITOR
            string path = System.IO.Path.Combine(Application.persistentDataPath, filename);
            SaveWavFile(path, audioData, sampleRate);
            Debug.Log($"[AudioRecorder] Saved WAV: {path}");
#endif
        }

        private void SaveWavFile(string path, float[] samples, int sampleRate)
        {
            using (var fs = new System.IO.FileStream(path, System.IO.FileMode.Create))
            {
                int byteCount = samples.Length * 2;
                byte[] header = new byte[44];

                Array.Copy(System.Text.Encoding.ASCII.GetBytes("RIFF"), 0, header, 0, 4);
                BitConverter.GetBytes(36 + byteCount).CopyTo(header, 4);
                Array.Copy(System.Text.Encoding.ASCII.GetBytes("WAVE"), 0, header, 8, 4);
                Array.Copy(System.Text.Encoding.ASCII.GetBytes("fmt "), 0, header, 12, 4);
                BitConverter.GetBytes(16).CopyTo(header, 16);
                BitConverter.GetBytes((short)1).CopyTo(header, 20);
                BitConverter.GetBytes((short)1).CopyTo(header, 22);
                BitConverter.GetBytes(sampleRate).CopyTo(header, 24);
                BitConverter.GetBytes(sampleRate * 2).CopyTo(header, 28);
                BitConverter.GetBytes((short)2).CopyTo(header, 32);
                BitConverter.GetBytes((short)16).CopyTo(header, 34);
                Array.Copy(System.Text.Encoding.ASCII.GetBytes("data"), 0, header, 36, 4);
                BitConverter.GetBytes(byteCount).CopyTo(header, 40);

                fs.Write(header, 0, 44);

                foreach (float sample in samples)
                {
                    short intSample = (short)(Mathf.Clamp(sample, -1f, 1f) * 32767f);
                    fs.Write(BitConverter.GetBytes(intSample), 0, 2);
                }
            }
        }

        #endregion
    }
}