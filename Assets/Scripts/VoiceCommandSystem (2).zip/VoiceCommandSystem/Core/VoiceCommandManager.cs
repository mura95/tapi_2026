using UnityEngine;
using System.Threading.Tasks;
using VoiceCommandSystem.Commands;
using VoiceCommandSystem.Commands.DogCommands;
using VoiceCommandSystem.Recognizers;

namespace VoiceCommandSystem.Core
{
    /// <summary>
    /// 音声コマンドシステムのメインマネージャー（Wake Word対応版）
    /// </summary>
    [RequireComponent(typeof(VoiceInputDetector))]
    [RequireComponent(typeof(AudioRecorder))]
    public class VoiceCommandManager : MonoBehaviour
    {
        #region Singleton
        private static VoiceCommandManager instance;
        public static VoiceCommandManager Instance => instance;

        void Awake()
        {
            if (instance != null && instance != this)
            {
                Destroy(gameObject);
                return;
            }
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        #endregion

        [Header("機能設定")]
        [SerializeField] private bool enableVoiceCommand = true;

        [Header("API設定")]
        [Tooltip("APIキー設定ファイル（Resources/VoiceCommandConfig.asset）")]
        [SerializeField] private VoiceCommandConfig config;

        [Header("OpenAI API 設定（非推奨：直接指定）")]
        [Tooltip("⚠️ 非推奨：Configファイルを使用してください")]
        [SerializeField] private bool useOpenAI = true;
        [Tooltip("⚠️ GitHubにプッシュしないでください！環境変数またはConfigファイルを使用")]
        [SerializeField] private string openAIApiKey = "";

        [Header("ローカルWhisper設定")]
        [SerializeField] private bool useLocalWhisper = true;

        [Header("参照")]
        [SerializeField] private DogController dogController;

        [Header("デバッグ")]
        [SerializeField] private bool showDebugLog = true;

        // コンポーネント（事前アタッチ）
        private VoiceInputDetector inputDetector;
        private AudioRecorder audioRecorder;
        private RecognizerSelector recognizerSelector;
        private VoiceCommandRegistry commandRegistry;

        // 状態
        private bool isInitialized = false;
        private bool isProcessing = false;
        private string resultMessage = "";
        private float resultDisplayEndTime = 0f;
        private bool isListeningEnabled = true; // Wake Word用

        async void Start()
        {
            if (!enableVoiceCommand)
            {
                Debug.Log("[VoiceCommandManager] Voice command system is disabled");
                enabled = false;
                return;
            }

            await InitializeSystem();
        }

        private async Task InitializeSystem()
        {
            Debug.Log("========================================");
            Debug.Log("[VoiceCommandManager] Initializing Voice Command System");
            Debug.Log("========================================");

            try
            {
                // DogControllerの取得
                if (dogController == null)
                {
                    dogController = FindObjectOfType<DogController>();
                    if (dogController == null)
                    {
                        Debug.LogWarning("[VoiceCommandManager] DogController not found");
                    }
                }

                // 1. VoiceInputDetector の取得（RequireComponentで自動追加）
                InitializeInputDetector();

                // 2. AudioRecorder の取得（RequireComponentで自動追加）
                InitializeAudioRecorder();

                // 3. 認識エンジンの初期化
                await InitializeRecognizers();

                // 4. コマンドレジストリの初期化
                InitializeCommandRegistry();

                isInitialized = true;
                Debug.Log("[VoiceCommandManager] ✅ Initialization completed");
                Debug.Log("========================================");
            }
            catch (System.Exception e)
            {
                Debug.LogError($"[VoiceCommandManager] ❌ Initialization failed: {e.Message}");
                enabled = false;
            }
        }

        private void InitializeInputDetector()
        {
            inputDetector = GetComponent<VoiceInputDetector>();
            if (inputDetector == null)
            {
                Debug.LogError("[VoiceCommandManager] VoiceInputDetector not found!");
                return;
            }

            inputDetector.OnRecordingStarted += HandleRecordingStarted;
            inputDetector.OnRecordingStopped += HandleRecordingStopped;

            Debug.Log("[VoiceCommandManager] VoiceInputDetector initialized");
        }

        private void InitializeAudioRecorder()
        {
            audioRecorder = GetComponent<AudioRecorder>();
            if (audioRecorder == null)
            {
                Debug.LogError("[VoiceCommandManager] AudioRecorder not found!");
                return;
            }

            Debug.Log("[VoiceCommandManager] AudioRecorder initialized");
        }

        private async Task InitializeRecognizers()
        {
            // 1. Configファイルから読み込み（最優先）
            if (config != null && config.HasApiKey())
            {
                openAIApiKey = config.OpenAIApiKey;
                useOpenAI = config.UseOpenAI;
                useLocalWhisper = config.UseLocalWhisper;
                Debug.Log("[VoiceCommandManager] API key loaded from Config file");
            }
            // 2. 環境変数から読み込み（次の優先度）
            else if (string.IsNullOrEmpty(openAIApiKey))
            {
                openAIApiKey = System.Environment.GetEnvironmentVariable("OPENAI_API_KEY");
                if (!string.IsNullOrEmpty(openAIApiKey))
                {
                    Debug.Log("[VoiceCommandManager] API key loaded from environment variable");
                }
            }

            if (useOpenAI && string.IsNullOrEmpty(openAIApiKey))
            {
                Debug.LogWarning("[VoiceCommandManager] ⚠️ OpenAI API key not set. Please create a VoiceCommandConfig asset or set OPENAI_API_KEY environment variable.");
                useOpenAI = false;
            }

            recognizerSelector = new RecognizerSelector(
                openAIApiKey: useOpenAI ? openAIApiKey : null,
                preferOnline: useOpenAI,
                fallbackToLocal: useLocalWhisper
            );

            bool success = await recognizerSelector.InitializeAsync();

            if (!success)
            {
                Debug.LogError("[VoiceCommandManager] Failed to initialize recognizer");
                throw new System.Exception("No recognizer available");
            }

            Debug.Log("[VoiceCommandManager] Recognizers initialized");
        }

        private void InitializeCommandRegistry()
        {
            commandRegistry = new VoiceCommandRegistry();
            RegisterDogCommands();

            if (showDebugLog)
            {
                commandRegistry.LogAllCommands();
            }

            Debug.Log("[VoiceCommandManager] CommandRegistry initialized");
        }

        private void RegisterDogCommands()
        {
            if (dogController == null)
            {
                Debug.LogWarning("[VoiceCommandManager] DogController is null");
                return;
            }

            // BasicCommands
            commandRegistry.RegisterCommands(
                new SitCommand(dogController),
                new PawCommand(dogController),
                new OkawariCommand(dogController),
                new DownCommand(dogController),
                new StandCommand(dogController),
                new WaitCommand(dogController),
                new OkayCommand(dogController)
            );

            // MovementCommands
            commandRegistry.RegisterCommands(
                new ComeCommand(dogController),
                new TurnCommand(dogController),
                new JumpCommand(dogController)
            );

            // TrickCommands
            commandRegistry.RegisterCommands(
                new BangCommand(dogController),
                new ChinChinCommand(dogController),
                new HighFiveCommand(dogController)
            );

            // CommunicationCommands
            commandRegistry.RegisterCommands(
                new BarkCommand(dogController),
                new QuietCommand(dogController)
            );

            // PraiseCommands
            commandRegistry.RegisterCommands(
                new GoodBoyCommand(dogController),
                new GreatCommand(dogController),
                new WellDoneCommand(dogController),
                new AmazingCommand(dogController),
                new SmartCommand(dogController),
                new CuteCommand(dogController),
                new LoveCommand(dogController),
                new LikeCommand(dogController),
                new LoveLoveCommand(dogController),
                new CheerCommand(dogController),
                new FightCommand(dogController),
                new YouCanDoItCommand(dogController),
                new RewardCommand(dogController),
                new TreatCommand(dogController),
                new YummyCommand(dogController)
            );

            Debug.Log("[VoiceCommandManager] All dog commands registered (30 commands)");
        }

        private void HandleRecordingStarted()
        {
            // ★追加: リスニング状態チェック
            if (!isListeningEnabled)
            {
                Debug.Log("[VoiceCommandManager] Command ignored - Wake word required");
                return;
            }

            if (!isInitialized || isProcessing)
            {
                Debug.LogWarning("[VoiceCommandManager] Cannot start recording");
                return;
            }

            Debug.Log("[VoiceCommandManager] 🎙️ Recording started");

            bool success = audioRecorder.StartRecording();
            if (!success)
            {
                Debug.LogError("[VoiceCommandManager] Failed to start recording");
            }
        }

        private async void HandleRecordingStopped()
        {
            if (!isInitialized)
            {
                Debug.LogWarning("[VoiceCommandManager] System not initialized");
                return;
            }

            Debug.Log("[VoiceCommandManager] 🛑 Recording stopped - processing...");

            float[] audioData = audioRecorder.StopRecording();

            if (audioData == null || audioData.Length == 0)
            {
                Debug.LogWarning("[VoiceCommandManager] No audio data captured");
                return;
            }

            await ProcessAudioAsync(audioData);
        }

        private async Task ProcessAudioAsync(float[] audioData)
        {
            if (isProcessing) return;

            isProcessing = true;
            resultMessage = "";

            try
            {
                string recognizedText = await recognizerSelector.RecognizeAsync(
                    audioData,
                    audioRecorder.SampleRate
                );

                if (string.IsNullOrEmpty(recognizedText))
                {
                    resultMessage = "❌ 認識不可\n再度試して";
                    resultDisplayEndTime = Time.time + 2f;
                    return;
                }

                // コマンド実行
                int executedCount = commandRegistry.ExecuteMatchingCommands(
                    recognizedText,
                    recognizerSelector.RecognizerName,
                    confidence: 1.0f
                );

                if (executedCount == 0)
                {
                    resultMessage = $"「{recognizedText}」\n\nコマンドが見つかりません";
                    resultDisplayEndTime = Time.time + 3f;
                }
                else
                {
                    resultMessage = $"✅ 実行完了\n({recognizedText})";
                    resultDisplayEndTime = Time.time + 2f;
                }
            }
            catch (System.Exception e)
            {
                resultMessage = "❌ エラーが発生しました\nもう一度お試しください";
                resultDisplayEndTime = Time.time + 2f;
            }
            finally
            {
                isProcessing = false;
            }
        }

        // ★追加: Wake Word用メソッド
        public void OnWakeWordDetected(float score)
        {
            Debug.Log($"[VoiceCommandManager] Wake word detected with score: {score:F3}");
            // 必要に応じて特別な処理を追加
        }

        public void SetListeningEnabled(bool enabled)
        {
            isListeningEnabled = enabled;
            Debug.Log($"[VoiceCommandManager] Listening {(enabled ? "enabled" : "disabled")}");
        }

        public bool CanProcessCommand()
        {
            return isListeningEnabled;
        }

        public void SetApiKey(string apiKey)
        {
            openAIApiKey = apiKey;
            Debug.Log("[VoiceCommandManager] API key updated");
        }

        public void SetEnabled(bool enabled)
        {
            enableVoiceCommand = enabled;
            this.enabled = enabled;

            if (inputDetector != null)
            {
                inputDetector.enabled = enabled;
            }

            Debug.Log($"[VoiceCommandManager] {(enabled ? "ENABLED" : "DISABLED")}");
        }

        public void RegisterCommand(IVoiceCommand command)
        {
            commandRegistry?.RegisterCommand(command);
        }

        public bool UnregisterCommand(IVoiceCommand command)
        {
            return commandRegistry?.UnregisterCommand(command) ?? false;
        }

        public bool IsInitialized => isInitialized;
        public bool IsProcessing => isProcessing;
        public AudioRecorder AudioRecorder => audioRecorder;

        void OnDestroy()
        {
            if (inputDetector != null)
            {
                inputDetector.OnRecordingStarted -= HandleRecordingStarted;
                inputDetector.OnRecordingStopped -= HandleRecordingStopped;
            }

            recognizerSelector?.Dispose();

            Debug.Log("[VoiceCommandManager] Cleaned up");
        }

        void OnGUI()
        {
            if (!showDebugLog || !isInitialized) return;

            GUIStyle style = new GUIStyle(GUI.skin.label);
            style.fontSize = 20;
            style.alignment = TextAnchor.MiddleCenter;

            // 背景
            Texture2D bgTexture = new Texture2D(1, 1);
            bgTexture.SetPixel(0, 0, new Color(0, 0, 0, 0.8f));
            bgTexture.Apply();
            style.normal.background = bgTexture;
            style.padding = new RectOffset(5, 5, 5, 5);

            string displayText = "";

            // 処理中の表示
            if (isProcessing)
            {
                style.normal.textColor = Color.yellow;
                displayText = "⏳ 認識中...";
            }
            // 結果の表示（2秒間）
            else if (Time.time < resultDisplayEndTime)
            {
                // メッセージの内容で色を変える
                if (resultMessage.Contains("✅"))
                {
                    style.normal.textColor = Color.green;
                }
                else if (resultMessage.Contains("❌"))
                {
                    style.normal.textColor = Color.red;
                }
                else
                {
                    style.normal.textColor = Color.yellow;
                }
                displayText = resultMessage;
            }
            else
            {
                return;
            }

            // 中央に表示
            GUI.Label(new Rect(
                Screen.width / 2 - 250,
                Screen.height / 2 - 50,
                500, 100
            ), displayText, style);
        }
    }
}