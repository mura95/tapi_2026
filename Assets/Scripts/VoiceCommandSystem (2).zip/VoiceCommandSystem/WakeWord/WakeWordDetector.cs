using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.InferenceEngine;

namespace VoiceCommandSystem.WakeWord
{
    /// <summary>
    /// Wake Word検出器 (Unity Inference Engine版)
    /// Unity 6完全対応 - ModelAsset方式
    /// </summary>
    public class WakeWordDetector : MonoBehaviour
    {
        [Header("Model Settings")]
        [SerializeField] private ModelAsset modelAsset;

        [Header("Detection Settings")]
        [SerializeField, Range(0f, 1f)] private float detectionThreshold = 0.85f;
        [SerializeField] private float bufferDuration = 1.0f;
        [SerializeField] private float detectionCooldown = 2.0f;

        [Header("Audio Settings")]
        [SerializeField] private int sampleRate = 16000;

        [Header("Backend")]
        [SerializeField] private BackendType backend = BackendType.CPU;

        [Header("Debug")]
        [SerializeField] private bool showDebugLog = true;

        // モデル
        private Model runtimeModel;
        private Worker worker;

        // オーディオバッファ
        private Queue<float> audioBuffer;
        private int bufferSize;

        // クールダウン管理
        private float lastDetectionTime;

        // 特徴量抽出パラメータ
        private const int N_MFCC = 20;
        private const int FEATURE_DIM = 40;
        private const int HOP_LENGTH = 512;

        // イベント
        public event Action<float> OnWakeWordDetected;
        public event Action<float> OnDetectionScore;

        // プロパティ
        public bool IsInitialized { get; private set; }
        public float CurrentScore { get; private set; }
        public string ModelInfo { get; private set; }

        private void Awake()
        {
            bufferSize = Mathf.RoundToInt(bufferDuration * sampleRate);
            audioBuffer = new Queue<float>(bufferSize);
        }

        private void Start()
        {
            InitializeModel();
        }

        private void OnDestroy()
        {
            CleanupModel();
        }

        /// <summary>
        /// モデルの初期化（ModelAsset方式）
        /// </summary>
        private void InitializeModel()
        {
            Log("Initializing Wake Word Detector (Unity Inference Engine)...");

            if (modelAsset == null)
            {
                Debug.LogError("[WakeWordDetector] Model Asset not assigned!");
                return;
            }

            try
            {
                // ModelAssetからロード（正しい方法）
                runtimeModel = ModelLoader.Load(modelAsset);

                // モデル情報を記録
                ModelInfo = $"Inputs: {runtimeModel.inputs.Count}, Outputs: {runtimeModel.outputs.Count}";

                // Workerを作成
                worker = new Worker(runtimeModel, backend);

                IsInitialized = true;
                Log("✓ Wake Word Detector initialized successfully");
                Log($"Backend: {backend}");
                Log($"Detection threshold: {detectionThreshold}");
                Log($"Model info: {ModelInfo}");
            }
            catch (Exception e)
            {
                Debug.LogError($"[WakeWordDetector] Failed to initialize model: {e.Message}\n{e.StackTrace}");
                IsInitialized = false;
            }
        }

        /// <summary>
        /// モデルのクリーンアップ
        /// </summary>
        private void CleanupModel()
        {
            worker?.Dispose();
            worker = null;
            Log("Wake Word Detector cleaned up");
        }

        /// <summary>
        /// 音声データを処理
        /// </summary>
        public void ProcessAudioData(float[] audioData)
        {
            if (!IsInitialized || audioData == null || audioData.Length == 0)
                return;

            // バッファに追加
            foreach (float sample in audioData)
            {
                if (audioBuffer.Count >= bufferSize)
                    audioBuffer.Dequeue();

                audioBuffer.Enqueue(sample);
            }

            // バッファが満タンになったら判定
            if (audioBuffer.Count >= bufferSize)
            {
                DetectWakeWord();
            }
        }

        /// <summary>
        /// Wake Word検出
        /// </summary>
        private void DetectWakeWord()
        {
            // クールダウン中はスキップ
            if (Time.time - lastDetectionTime < detectionCooldown)
                return;

            try
            {
                // 特徴量抽出
                float[] features = ExtractFeatures(audioBuffer.ToArray());

                if (features == null || features.Length != FEATURE_DIM)
                {
                    Log($"Feature extraction failed or wrong dimension: {features?.Length ?? 0}");
                    return;
                }

                // 推論実行
                float score = Predict(features);
                CurrentScore = score;

                // スコアイベント発火
                OnDetectionScore?.Invoke(score);

                // 検出判定
                if (score >= detectionThreshold)
                {
                    Log($"🎤 Wake word detected! Score: {score:F3}");
                    lastDetectionTime = Time.time;
                    OnWakeWordDetected?.Invoke(score);
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"[WakeWordDetector] Detection error: {e.Message}");
            }
        }

        /// <summary>
        /// 音声から特徴量を抽出（MFCC 40次元）
        /// </summary>
        private float[] ExtractFeatures(float[] audio)
        {
            try
            {
                float[] normalizedAudio = NormalizeAudioLength(audio);

                // MFCC 20次元
                float[] mfcc = ExtractMFCC(normalizedAudio);

                // Delta MFCC 20次元
                float[] delta = CalculateDelta(mfcc);

                // 連結
                float[] features = new float[FEATURE_DIM];
                Array.Copy(mfcc, 0, features, 0, N_MFCC);
                Array.Copy(delta, 0, features, N_MFCC, N_MFCC);

                return features;
            }
            catch (Exception e)
            {
                Debug.LogError($"[WakeWordDetector] Feature extraction error: {e.Message}");
                return null;
            }
        }

        private float[] NormalizeAudioLength(float[] audio)
        {
            if (audio.Length == sampleRate)
                return audio;

            float[] result = new float[sampleRate];

            if (audio.Length > sampleRate)
            {
                Array.Copy(audio, result, sampleRate);
            }
            else
            {
                Array.Copy(audio, result, audio.Length);
            }

            return result;
        }

        private float[] ExtractMFCC(float[] audio)
        {
            // フレーム分割
            int frameCount = audio.Length / HOP_LENGTH;
            List<float> mfccValues = new List<float>();

            for (int coef = 0; coef < N_MFCC; coef++)
            {
                List<float> coefficients = new List<float>();

                for (int f = 0; f < frameCount; f++)
                {
                    int start = f * HOP_LENGTH;
                    int end = Mathf.Min(start + HOP_LENGTH, audio.Length);

                    float energy = 0f;
                    for (int i = start; i < end; i++)
                    {
                        energy += audio[i] * audio[i];
                    }
                    energy /= (end - start);

                    coefficients.Add(Mathf.Log(energy + 1e-9f));
                }

                // 平均を取る
                mfccValues.Add(coefficients.Average());
            }

            return mfccValues.ToArray();
        }

        private float[] CalculateDelta(float[] features)
        {
            // 簡易的なデルタ計算（差分）
            float[] delta = new float[features.Length];

            for (int i = 0; i < features.Length; i++)
            {
                if (i == 0)
                    delta[i] = features[1] - features[0];
                else if (i == features.Length - 1)
                    delta[i] = features[i] - features[i - 1];
                else
                    delta[i] = (features[i + 1] - features[i - 1]) / 2f;
            }

            return delta;
        }

        private float Predict(float[] features)
        {
            // Tensorを作成
            Tensor<float> inputTensor = new Tensor<float>(new TensorShape(1, FEATURE_DIM), features);

            try
            {
                // 推論実行
                worker.Schedule(inputTensor);

                // 出力取得
                Tensor<float> outputTensor = worker.PeekOutput() as Tensor<float>;

                // データをCPUに転送
                float[] output = outputTensor.DownloadToArray();

                // Softmax計算
                float logit0 = output[0];
                float logit1 = output[1];

                float exp0 = Mathf.Exp(logit0);
                float exp1 = Mathf.Exp(logit1);

                float probability = exp1 / (exp0 + exp1);

                return Mathf.Clamp01(probability);
            }
            finally
            {
                inputTensor.Dispose();
            }
        }

        public void SetThreshold(float threshold)
        {
            detectionThreshold = Mathf.Clamp01(threshold);
            Log($"Threshold updated: {detectionThreshold}");
        }

        public void SetBackend(BackendType newBackend)
        {
            if (backend == newBackend)
                return;

            backend = newBackend;

            if (IsInitialized && runtimeModel != null)
            {
                worker?.Dispose();
                worker = new Worker(runtimeModel, backend);
                Log($"Backend changed to: {backend}");
            }
        }

        public void ClearBuffer()
        {
            audioBuffer.Clear();
            Log("Audio buffer cleared");
        }

        private void Log(string message)
        {
            if (showDebugLog)
                Debug.Log($"[WakeWordDetector] {message}");
        }
    }
}