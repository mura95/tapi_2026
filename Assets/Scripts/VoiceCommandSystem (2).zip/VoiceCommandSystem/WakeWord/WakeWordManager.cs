using UnityEngine;
using System.Collections;

namespace VoiceCommandSystem.WakeWord
{
    /// <summary>
    /// Wake Word統合マネージャー
    /// 既存の音声コマンドシステムにWake Word機能を追加
    /// </summary>
    [RequireComponent(typeof(WakeWordDetector))]
    public class WakeWordManager : MonoBehaviour
    {
        [Header("References")]
        [SerializeField] private Core.VoiceCommandManager voiceCommandManager;
        [SerializeField] private Core.AudioRecorder audioRecorder;

        [Header("Wake Word Behavior")]
        [SerializeField] private bool enableWakeWord = true;
        [SerializeField] private bool requireWakeWordForCommands = false;
        [SerializeField] private float commandWindowDuration = 5f;

        [Header("Feedback")]
        [SerializeField] private AudioClip wakeWordDetectedSound;
        [SerializeField] private GameObject wakeWordIndicator;

        private WakeWordDetector detector;
        private AudioSource audioSource;
        private bool isCommandWindowActive;
        private float commandWindowEndTime;

        // 状態
        public bool IsWakeWordEnabled => enableWakeWord;
        public bool IsCommandWindowActive => isCommandWindowActive;
        public float CurrentDetectionScore => detector?.CurrentScore ?? 0f;

        private void Awake()
        {
            detector = GetComponent<WakeWordDetector>();
            audioSource = GetComponent<AudioSource>();

            if (audioSource == null && wakeWordDetectedSound != null)
            {
                audioSource = gameObject.AddComponent<AudioSource>();
            }

            if (wakeWordIndicator != null)
            {
                wakeWordIndicator.SetActive(false);
            }
        }

        private void OnEnable()
        {
            if (detector != null)
            {
                detector.OnWakeWordDetected += OnWakeWordDetected;
                detector.OnDetectionScore += OnDetectionScore;
            }

            if (audioRecorder != null)
            {
                audioRecorder.OnAudioDataReady += OnAudioDataReady;
            }
        }

        private void OnDisable()
        {
            if (detector != null)
            {
                detector.OnWakeWordDetected -= OnWakeWordDetected;
                detector.OnDetectionScore -= OnDetectionScore;
            }

            if (audioRecorder != null)
            {
                audioRecorder.OnAudioDataReady -= OnAudioDataReady;
            }
        }

        private void Update()
        {
            // コマンドウィンドウのタイムアウト処理
            if (isCommandWindowActive && Time.time >= commandWindowEndTime)
            {
                CloseCommandWindow();
            }
        }

        /// <summary>
        /// 音声データを受信してWake Word検出に渡す
        /// </summary>
        private void OnAudioDataReady(float[] audioData)
        {
            if (!enableWakeWord || detector == null)
                return;

            // Wake Word検出処理
            detector.ProcessAudioData(audioData);
        }

        /// <summary>
        /// Wake Word検出時のコールバック
        /// </summary>
        private void OnWakeWordDetected(float score)
        {
            Debug.Log($"[WakeWordManager] Wake word detected! Score: {score:F3}");

            // フィードバック再生
            PlayWakeWordFeedback();

            // コマンドウィンドウを開く
            if (requireWakeWordForCommands)
            {
                OpenCommandWindow();
            }

            // 音声コマンドマネージャーに通知
            if (voiceCommandManager != null)
            {
                voiceCommandManager.OnWakeWordDetected(score);
            }
        }

        /// <summary>
        /// 検出スコア更新時のコールバック
        /// </summary>
        private void OnDetectionScore(float score)
        {
            // UI更新などに使用可能
            // 例: スコアバーの表示
        }

        /// <summary>
        /// コマンドウィンドウを開く
        /// </summary>
        private void OpenCommandWindow()
        {
            isCommandWindowActive = true;
            commandWindowEndTime = Time.time + commandWindowDuration;

            if (wakeWordIndicator != null)
            {
                wakeWordIndicator.SetActive(true);
            }

            // 音声認識を有効化
            if (voiceCommandManager != null)
            {
                voiceCommandManager.SetListeningEnabled(true);
            }

            Debug.Log($"[WakeWordManager] Command window opened for {commandWindowDuration} seconds");
        }

        /// <summary>
        /// コマンドウィンドウを閉じる
        /// </summary>
        private void CloseCommandWindow()
        {
            isCommandWindowActive = false;

            if (wakeWordIndicator != null)
            {
                wakeWordIndicator.SetActive(false);
            }

            // Wake Wordが必要な場合は音声認識を無効化
            if (requireWakeWordForCommands && voiceCommandManager != null)
            {
                voiceCommandManager.SetListeningEnabled(false);
            }

            Debug.Log("[WakeWordManager] Command window closed");
        }

        /// <summary>
        /// Wake Word検出のフィードバック再生
        /// </summary>
        private void PlayWakeWordFeedback()
        {
            if (audioSource != null && wakeWordDetectedSound != null)
            {
                audioSource.PlayOneShot(wakeWordDetectedSound);
            }
        }

        /// <summary>
        /// Wake Word機能の有効/無効を切り替え
        /// </summary>
        public void SetWakeWordEnabled(bool enabled)
        {
            enableWakeWord = enabled;

            if (!enabled && isCommandWindowActive)
            {
                CloseCommandWindow();
            }

            Debug.Log($"[WakeWordManager] Wake word {(enabled ? "enabled" : "disabled")}");
        }

        /// <summary>
        /// Wake Word必須モードの切り替え
        /// </summary>
        public void SetRequireWakeWord(bool require)
        {
            requireWakeWordForCommands = require;

            if (require && voiceCommandManager != null)
            {
                // Wake Word待機モードに
                voiceCommandManager.SetListeningEnabled(false);
            }
            else if (voiceCommandManager != null)
            {
                // 常時リスニングモードに
                voiceCommandManager.SetListeningEnabled(true);
            }

            Debug.Log($"[WakeWordManager] Require wake word: {require}");
        }

        /// <summary>
        /// コマンドウィンドウの時間を延長
        /// </summary>
        public void ExtendCommandWindow(float additionalTime)
        {
            if (isCommandWindowActive)
            {
                commandWindowEndTime += additionalTime;
                Debug.Log($"[WakeWordManager] Command window extended by {additionalTime}s");
            }
        }

        /// <summary>
        /// 検出閾値を設定
        /// </summary>
        public void SetDetectionThreshold(float threshold)
        {
            if (detector != null)
            {
                detector.SetThreshold(threshold);
            }
        }
    }
}